package controllers;

import item.Item;
import item.ItemDAO;
import pedido.Pedido;
import pedido.PedidoDAO;
import producto.Producto;
import producto.ProductoDAO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.*;
import javafx.util.StringConverter;

import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    @FXML
    private Label info;
    @FXML
    private TableColumn<Pedido,String> cCodigo;
    @FXML
    private TableColumn<Pedido,String> cFecha;
    @FXML
    private TableColumn<Pedido,String> cTotal;
    @FXML
    private Button btnNuevoPedido;
    @FXML
    private TableColumn<Item,String> cProducto;
    @FXML
    private ChoiceBox<Producto> comboProducto;
    @FXML
    private Button btnAñadir;
    @FXML
    private Button btnBorrar;
    @FXML
    private TextField txtCodigo;
    @FXML
    private Button btnBorrarPedido;

    private ArrayList<Pedido> pedidos = new ArrayList<>(0);
    private ArrayList<Producto> productos = new ArrayList<>(0);
    private Pedido pedidoActual = null;
    private Item itemActual = null;

    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final ProductoDAO productoDAO = new ProductoDAO();
    private final ItemDAO itemDAO = new ItemDAO();

    ObservableList<Pedido> observableTablaPedidos = FXCollections.observableArrayList();
    @FXML
    private TableView<Pedido> tablapedidos;
    @FXML
    private Button btnRefrescarPedido;
    @FXML
    private TableView<Item> tablaproductos;
    @FXML
    private TableColumn<Item,String> cproductoCantidad;
    @FXML
    private Spinner<Integer> spinnerCantidadproducto;
    @FXML
    private Label labelcodigo;
    @FXML
    private Label labelcantidad;
    @FXML
    private TableColumn<Pedido,String> cCantidad;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        cCodigo.setCellValueFactory( (fila)->{
            var salida = fila.getValue().getCodigo();
            return new SimpleStringProperty(salida);
        });
        cFecha.setCellValueFactory( (fila)->{
            var salida = fila.getValue().getFecha().toString();
            return new SimpleStringProperty(salida);
        });
        cCantidad.setCellValueFactory( (fila)->{
            var salida = fila.getValue().getItems().size()+"";
            return new SimpleStringProperty(salida);
        });
        cTotal.setCellValueFactory( (fila)->{
            return new SimpleStringProperty(fila.getValue().getCalculoTotal()+"€");
        });
        cProducto.setCellValueFactory((fila)->{
            var salida = fila.getValue().getProducto().getNombre();
            return new SimpleStringProperty(salida);
        });
        cproductoCantidad.setCellValueFactory((fila)->{
            var salida = fila.getValue().getCantidad()+"";
            return new SimpleStringProperty(salida);
        });

        comboProducto.setConverter(new StringConverter<Producto>() {
            @Override
            public String toString(Producto producto) {
                return (producto!=null)?producto.getNombre():"";
            }

            @Override
            public Producto fromString(String s) {
                return null;
            }
        });

        spinnerCantidadproducto.setValueFactory( new SpinnerValueFactory.IntegerSpinnerValueFactory(1,99,1,1));

        tablapedidos.getSelectionModel().selectedItemProperty().addListener((observableValue, pedido, t1) -> {
            if(t1!=null) {
                pedidoActual = t1;
                actualizarTablaItems();
            }
        });

        tablaproductos.getSelectionModel().selectedItemProperty().addListener((observableValue, item, t1) -> {
            if(t1!=null) {
                itemActual = (Item) t1;
                actualizarFormularioItem();
            }
        });


        refrescarPedido();

        productos = (ArrayList<Producto>) productoDAO.getAll();
        comboProducto.getItems().addAll(productos);
    }


    private void actualizarFormularioItem() {
        info.setText( itemActual.toString() );
        comboProducto.setValue(itemActual.getProducto());
        spinnerCantidadproducto.getValueFactory().setValue(itemActual.getCantidad());
    }

    private void actualizarTablaItems() {
        info.setText( pedidoActual.toString() );
        labelcodigo.setText(pedidoActual.getCodigo());
        txtCodigo.setText(pedidoActual.getCodigo());
        labelcantidad.setText(pedidoActual.getCalculoTotal()+"€");

        ObservableList<Item> observableTablaItems = FXCollections.observableArrayList();
        observableTablaItems.addAll(pedidoActual.getItems());
        tablaproductos.setItems(observableTablaItems);

    }

    @FXML
    public void borrarPedido(ActionEvent actionEvent) {
        observableTablaPedidos.clear();
    }




    @FXML
    public void nuevoPedido(ActionEvent actionEvent) {
        if( pedidoDAO.getByCodigo( txtCodigo.getText() ) != null ){
            info.setText("No se permiten códigos duplicados");
        }else {
            Pedido p = new Pedido(txtCodigo.getText(),new Date());
            pedidoActual = pedidoDAO.save(p);
            info.setText("created!");
            txtCodigo.setText("");
        }
        refrescarPedido();
    }

    @FXML
    public void refrescarPedido() {
        observableTablaPedidos.clear();
        tablapedidos.getItems().clear();
        observableTablaPedidos.addAll((ArrayList<Pedido>) pedidoDAO.getAll());
        tablapedidos.setItems(observableTablaPedidos);
    }

    @FXML
    public void nuevoproducto(ActionEvent actionEvent) {
        Item item = new Item();
        item.setCantidad((Integer) spinnerCantidadproducto.getValue());
        item.setProducto( comboProducto.getValue() );
        pedidoActual.addItem(item);
        pedidoDAO.update(pedidoActual);

        refrescarPedido();
        actualizarTablaItems();

        txtCodigo.setText("");
    }

    @FXML
    public void borrarproducto(ActionEvent actionEvent) {
        if(itemActual!=null){
            itemDAO.remove(itemActual);
            itemActual=null;

            pedidoActual=pedidoDAO.get(pedidoActual.getId());

            refrescarPedido();
            actualizarTablaItems();
        }
    }
}
