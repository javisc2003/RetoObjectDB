package mierdecillas;

import item.Item;
import pedido.Pedido;
import producto.Producto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Data {

    public static List<Producto> generateProducts(){
        List<Producto> listaProductos = new ArrayList<>();
        listaProductos.add(new Producto(1L, "Smartphone", 299.99));
        listaProductos.add(new Producto(2L, "Portátil", 699.99));
        listaProductos.add(new Producto(3L, "Auriculares inalámbricos", 19.99));
        listaProductos.add(new Producto(4L, "Televisor LED", 239.99));
        listaProductos.add(new Producto(5L, "Tableta", 249.99));
        listaProductos.add(new Producto(6L, "Ratón inalámbrico", 29.99));
        listaProductos.add(new Producto(7L, "Teclado mecánico", 39.99));
        listaProductos.add(new Producto(8L, "Impresora multifunción", 399.99));
        listaProductos.add(new Producto(9L, "Altavoces Bluetooth", 49.99));
        listaProductos.add(new Producto(10L, "Monitor LCD", 349.99));
        return listaProductos;
    }

    public static List<Pedido> generatePedidos(){
        ArrayList<Pedido> listaPedidos = new ArrayList<>();

        Pedido p = new Pedido("P001", generateDate());
        p.addItem( new Item( 2,generateProducts().get(0) ) );
        p.addItem( new Item( 1,generateProducts().get(1) ) );
        p.addItem( new Item( 5,generateProducts().get(2) ) );
        listaPedidos.add(p);

        listaPedidos.add(new Pedido("P002", generateDate()));
        listaPedidos.add(new Pedido("P003", generateDate()));
        listaPedidos.add(new Pedido("P004", generateDate()));
        return listaPedidos;
    }


    private static Date generateDate() {
        long now = System.currentTimeMillis();
        long randomDate = ThreadLocalRandom.current().nextLong(now - 2592000000L, now + 2592000000L);
        return new Date(randomDate);
    }
}
