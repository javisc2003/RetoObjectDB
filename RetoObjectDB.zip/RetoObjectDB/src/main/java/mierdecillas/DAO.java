package mierdecillas;

import item.Item;

import java.util.List;

public interface DAO<T> {
    T save( T t);
    T update( T t);
    boolean remove(T t);
    T get( Long id);
    List<T> getAll();
}
