module app {
    requires javafx.controls;
    requires javafx.fxml;
    requires javax.persistence;
    requires java.naming;
    requires lombok;
    requires java.logging;
    requires java.sql;


    opens app to javafx.fxml;
    opens producto;
    opens pedido;
    opens item;

    exports app;
    exports controllers;
    opens controllers to javafx.fxml;
}